#include "InputBox.h"



//InputBox::InputBox()
//{
//}
//
//InputBox::InputBox(SDL_Rect & pos, iPoint posOffsetA, iPoint posOffsetB, iPoint posOffsetC, SDL_Rect image_section, p2SString fontPath, SDL_Color textColor, p2SString label, int size, j1Module * callback, bool draggable) : InteractiveLabelledImage(SDL_Rect & pos, iPoint posOffsetA, iPoint posOffsetB, iPoint posOffsetC, SDL_Rect image_section, p2SString fontPath, SDL_Color textColor, p2SString label, int size, j1Module* callback, bool draggable)
//{
//}
//
//
//InputBox::~InputBox()
//{
//}
